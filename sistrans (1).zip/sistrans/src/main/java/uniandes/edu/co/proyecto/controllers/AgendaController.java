package uniandes.edu.co.proyecto.controllers;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import uniandes.edu.co.proyecto.services.AgendaService;

@Controller
public class AgendaController {
    
    @Autowired
    private AgendaService agendaService;

    @GetMapping(path = "/agendas", produces = "application/json")
    @ResponseBody()
    public List<Map<String, Object>> findAll() {
        return agendaService.findAll();
    }

    @GetMapping(path = "/agendas_serializable", produces = "application/json")
    @ResponseBody()
    public List<Map<String, Object>> findAllSerializable() {
        return agendaService.findAllSerializable();
    }

    @PostMapping("/agendas/{idIpsMedico}/{fecha}/{hora}/asignar")
    public ResponseEntity<Void> asignar(
            @PathVariable long idIpsMedico,
            @PathVariable String fecha,
            @PathVariable String hora) {
        
        String fechaHora = fecha + " " + hora.replace("-", ":");
        System.out.println("\n\n\n\n\n\n\n\nasignar: " + idIpsMedico + " " + fechaHora);
        boolean ok = agendaService.asignar(idIpsMedico, fechaHora);
        return ok
            ? ResponseEntity.noContent().build()
            : ResponseEntity.notFound().build();
    }

    @PostMapping("/agendas_serializable/{idIpsMedico}/{fecha}/{hora}/asignar")
    public ResponseEntity<Void> asignarSerializable(
            @PathVariable long idIpsMedico,
            @PathVariable String fecha,
            @PathVariable String hora) {
        
        String fechaHora = fecha + " " + hora.replace("-", ":");
        System.out.println("\n\n\n\n\n\n\n\nasignarSerializable: " + idIpsMedico + " " + fechaHora);
        boolean ok = agendaService.asignarSerializable(idIpsMedico, fechaHora);
        return ok
            ? ResponseEntity.noContent().build()
            : ResponseEntity.notFound().build();
    }
}
