package uniandes.edu.co.proyecto.repositories;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class AgendaRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Map<String,Object>> queryForList(String sql) {
        return jdbcTemplate.queryForList(sql);
    }

    public List<Map<String,Object>> queryForListSerializable(String sql) {
        return jdbcTemplate.queryForList(sql);
    }

    public int asignarAgenda(long idIpsMedico, String fechaHora) {
        String sql = "UPDATE AGENDA "
                   + "SET ESTADO = ? "
                   + "WHERE ID_IPS_MEDICO = ? AND FECHA_HORA = TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS')";
        return jdbcTemplate.update(sql,
            "ASIGNADO",
            idIpsMedico,
            fechaHora
        );
    }

    public Map<String,Object> findAgendaForUpdate(long idIpsMedico, String fechaHora) {
        String sql = ""
          + "SELECT * "
          + "FROM AGENDA "
          + "WHERE ID_IPS_MEDICO = ? "
          + "  AND FECHA_HORA = TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS') "
          + "FOR UPDATE";

        return jdbcTemplate.queryForMap(sql, idIpsMedico, fechaHora);
    }
    
}
