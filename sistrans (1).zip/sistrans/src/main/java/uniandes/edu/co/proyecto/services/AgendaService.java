package uniandes.edu.co.proyecto.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import uniandes.edu.co.proyecto.repositories.AgendaRepository;

@Service
public class AgendaService {
    
    @Autowired
    private AgendaRepository agendaRepository;

    public List<Map<String,Object>> findAll() {
        return agendaRepository.queryForList("SELECT * FROM AGENDA");
    }

    @Transactional(
      readOnly = true,
      isolation = Isolation.SERIALIZABLE
    )
    public List<Map<String,Object>> findAllSerializable() {
        agendaRepository.queryForList("SELECT * FROM AGENDA");
        try {
            Thread.sleep(30_000);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Thread interrupted", ie);
        }
        return agendaRepository.queryForListSerializable("SELECT * FROM AGENDA");
    }

    public boolean asignar(long idIpsMedico, String fechaHora) {
        Map<String,Object> agenda = agendaRepository.findAgendaForUpdate(idIpsMedico, fechaHora);
        if (agenda == null) {
            return false;
        }
        if (agenda.get("ESTADO").equals("ASIGNADO")) {
            throw new IllegalStateException("Agenda already assigned");
        }
        int rows = agendaRepository.asignarAgenda(idIpsMedico, fechaHora);
        return rows == 1;
    }

    @Transactional(
      readOnly = false,
      isolation = Isolation.SERIALIZABLE
    )
    public boolean asignarSerializable(long idIpsMedico, String fechaHora) {
        agendaRepository.queryForList("SELECT * FROM AGENDA");
        try {
            Thread.sleep(15_000);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Thread interrupted", ie);
        }
        Map<String,Object> agenda = agendaRepository.findAgendaForUpdate(idIpsMedico, fechaHora);
        if (agenda == null) {
            return false;
        }
        if (agenda.get("ESTADO").equals("ASIGNADO")) {
            throw new IllegalStateException("Agenda already assigned");
        }
        int rows = agendaRepository.asignarAgenda(idIpsMedico, fechaHora);
        return rows == 1;
    }
}
